import 'dart:async';

import 'package:cm_app/app/constants.dart';
import 'package:cm_app/app/core/models/movie.dart';
import 'package:cm_app/app/route_helper.dart';
import 'package:cm_app/app/core/services/movie_services.dart';
import 'package:cm_app/app/ui/components/movie_grid_item.dart';
import 'package:flutter/material.dart';
import 'package:t_widgets/t_widgets.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  bool isSearching = false;
  List<Movie> list = [];
  Timer? _timer;

  @override
  void dispose() {
    if (_timer?.isActive ?? false) {
      _timer?.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Search')),
      body: CustomScrollView(
        slivers: [_getSearchbar(), _getSearchingProgress(), _getResultList()],
      ),
    );
  }

  Widget _getSearchbar() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: TSearchField(
          autofocus: true,
          onSubmitted: _onSearch,
          onChanged: (text) {
            // if (isSearching) return;

            if (_timer?.isActive ?? false) {
              _timer?.cancel();
            }

            _timer = Timer(Duration(milliseconds: 1500), () => _onSearch(text));
          },
        ),
      ),
    );
  }

  Widget _getSearchingProgress() {
    return SliverToBoxAdapter(
      child: !isSearching
          ? null
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: LinearProgressIndicator(),
            ),
    );
  }

  Widget _getResultList() {
    if (list.isEmpty) {
      return SliverFillRemaining(
        child: Center(
          child: Text(isSearching ? 'Searching...' : 'Not Found!...'),
        ),
      );
    }
    return SliverGrid.builder(
      itemCount: list.length,
      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 140,
        mainAxisExtent: 170,
        mainAxisSpacing: 5,
        crossAxisSpacing: 5,
      ),
      itemBuilder: (context, index) => MovieGridItem(
        movie: list[index],
        onClicked: (movie) => goMovieDetailScreen(context, movie: movie),
      ),
    );
  }

  Future<void> _onSearch(String text) async {
    try {
      setState(() {
        isSearching = true;
      });
      final url = '$apiSearchUrl=$text';
      list = await MovieServices.getMovies(url);

      if (!mounted) return;
      setState(() {
        isSearching = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        isSearching = false;
      });
      showTMessageDialogError(context, e.toString());
    }
  }
}
