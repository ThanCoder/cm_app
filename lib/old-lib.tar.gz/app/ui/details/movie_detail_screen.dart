import 'dart:convert';

import 'package:cm_app/app/core/models/movie.dart';
import 'package:cm_app/app/core/models/movie_detail.dart';
import 'package:cm_app/app/core/services/cache_services.dart';
import 'package:cm_app/app/core/services/client_services.dart';
import 'package:cm_app/app/ui/details/detail_app_bar.dart';
import 'package:cm_app/app/ui/details/movie_casts_page.dart';
import 'package:cm_app/app/ui/details/movie_download_list_page.dart';
import 'package:cm_app/app/ui/details/overview_viewer.dart';
import 'package:cm_app/app/ui/details/poster_app_bar.dart';
import 'package:cm_app/more_libs/setting/setting.dart';
import 'package:flutter/material.dart';
import 'package:t_widgets/t_widgets.dart';

class MovieDetailScreen extends StatefulWidget {
  final Movie movie;
  const MovieDetailScreen({super.key, required this.movie});

  @override
  State<MovieDetailScreen> createState() => _MovieDetailScreenState();
}

class _MovieDetailScreenState extends State<MovieDetailScreen> {
  @override
  void initState() {
    super.initState();
    init();
  }

  MovieDetail? detail;
  bool isLoading = false;
  String errorMessage = '';

  Future<void> init({bool isUsedCached = true}) async {
    try {
      setState(() {
        errorMessage = '';
        isLoading = true;
      });
      if (isUsedCached) {
        final cache = await CacheServices.getMovieCache(widget.movie.title);
        if (cache != null) {
          detail = cache;
          if (!mounted) return;
          setState(() {
            isLoading = false;
          });
          return;
        }
      }

      final res = await ClientServices.instance.getUrlContent(
        Setting.getForwardProxyUrl(widget.movie.url),
      );
      if (!mounted) return;
      isLoading = false;

      final map = jsonDecode(res);
      detail = MovieDetail.fromMap(map['data']);
      //set cache
      CacheServices.setMovieCache(widget.movie.title, detail: detail!);

      setState(() {});
    } catch (e) {
      errorMessage = e.toString();
      if (!mounted) return;
      setState(() {
        isLoading = false;
      });
      // showTMessageDialogError(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: RefreshIndicator.noSpinner(
          onRefresh: () async {
            init(isUsedCached: false);
          },
          child: NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              return [
                DetailAppBar<MovieDetail>(
                  movie: widget.movie,
                  onInit: () => init(isUsedCached: false),
                  detail: detail,
                ),
                PosterAppBar(movie: widget.movie),
                _getHeader(),
              ];
            },
            body: _getTabView(),
          ),
        ),
      ),
    );
  }

  Widget _getHeader() {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      snap: true,
      floating: true,
      pinned: false,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.movie.title),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow),
              Text(widget.movie.rating),
            ],
          ),
        ],
      ),
      bottom: TabBar(
        tabs: [
          Tab(text: 'Detail', icon: Icon(Icons.description)),
          Tab(text: 'သရုပ်ဆောင်များ', icon: Icon(Icons.people)),
          Tab(text: 'Download', icon: Icon(Icons.download)),
        ],
      ),
    );
  }

  Widget _getTabView() {
    if (isLoading) {
      return Center(child: TLoader.random());
    }
    if (detail == null || errorMessage.isNotEmpty) {
      return Center(
        child: RefreshButton(
          text: Text(errorMessage, style: TextStyle(color: Colors.red)),
          onClicked: init,
        ),
      );
    }
    return TabBarView(
      children: [
        OverviewViewer<MovieDetail>(movie: widget.movie, detail: detail),
        MovieCastsPage(list: detail!.castList),
        MovieDownloadListPage(list: detail!.downloadList),
      ],
    );
  }
}
